import { Routes } from '@angular/router';
import { Gestiondeusuariocomponent } from './components/gestiondeusuariocomponent/gestiondeusuariocomponent';
import { RegistroComponent } from './components/registrocomponent/registrocomponent';
import { LoginComponent } from './components/logincomponent/logincomponent';
import { Usuariocomponent } from './components/usuariocomponent/usuariocomponent';
import { roleGuard } from './service/role.guard';

export const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'registro', component: RegistroComponent },
  { path: 'admin', component: Gestiondeusuariocomponent, canActivate: [roleGuard], data: { role: 'ADMIN' } },
  { path: 'usuario', component: Usuariocomponent, canActivate: [roleGuard], data: { role: 'USER' } },
  { path: '**', redirectTo: '' }
];
