import { Injectable, inject } from '@angular/core';
import { Observable, map } from 'rxjs';
import { User } from '../model/user.model';
import { UserService } from './user.service';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private userService = inject(UserService);
  private signedInUser?: User;

  login(username: string, password: string): Observable<User | undefined> {
    const normalizedUsername = username.trim();
    return this.userService.getAll().pipe(
      map(users => {
        const user = users.find(item => item.username.trim() === normalizedUsername && item.password === password);
        this.signedInUser = user;
        return user;
      })
    );
  }

  get currentUser(): User | undefined {
    return this.signedInUser;
  }

  logout(): void {
    this.signedInUser = undefined;
  }
}
