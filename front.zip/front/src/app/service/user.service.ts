import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import {User} from '../model/user.model';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private users: User[] = [
    { id: 1, username: 'admin', password: '123', edad: 30, fechaDeNacimiento: '1995-05-12', role: 'ADMIN' },
    { id: 2, username: 'usuario1', password: '123', edad: 20, fechaDeNacimiento: '2006-06-20', role: 'USER' }
  ];

  private readonly storageKey = 'springfirstappfront.users';

  constructor() {
    if (typeof localStorage === 'undefined') return;

    try {
      const savedUsers = localStorage.getItem(this.storageKey);
      if (savedUsers) this.users = JSON.parse(savedUsers) as User[];
    } catch {
      // Si el almacenamiento está dañado, se conserva la lista inicial.
    }
  }

  getAll(): Observable<User[]> {
    return of([...this.users]);
  }

  count(): Observable<number> {
    return of(this.users.length);
  }

  exists(id: number): Observable<boolean> {
    return of(this.users.some(user => user.id === id));
  }

  getById(id: number): Observable<User | undefined> {
    return of(this.users.find(user => user.id === id));
  }

  createWithJson(user: User): Observable<string> {
    const exists = this.users.some(u => u.username === user.username);
    if (exists) {
      return throwError(() => ({ status: 406, error: 'Error al crear el usuario, el nombre ya está en uso' }));
    }
    const newId = this.users.length > 0 ? Math.max(...this.users.map(u => u.id!)) + 1 : 1;
    this.users.push({ ...user, id: newId });
    this.persistUsers();
    return of('Usuario creado exitosamente');
  }

  updateWithJson(id: number, user: User): Observable<string> {
    const index = this.users.findIndex(u => u.id === id);
    if (index === -1) {
      return throwError(() => ({ status: 404, error: 'Usuario no encontrado' }));
    }
    this.users[index] = { ...user, id };
    this.persistUsers();
    return of('Usuario actualizado exitosamente');
  }

  deleteById(id: number): Observable<string> {
    const index = this.users.findIndex(u => u.id === id);
    if (index === -1) {
      return throwError(() => ({ status: 404, error: 'Error al eliminar' }));
    }
    this.users.splice(index, 1);
    this.persistUsers();
    return of('Usuario eliminado exitosamente');
  }

  private persistUsers(): void {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(this.storageKey, JSON.stringify(this.users));
    }
  }
}
