export type Role = 'USER' | 'ADMIN';

export interface User{
  id?: number;
  username: string;
  password?: string;
  edad: number;
  fechaDeNacimiento: string;
  role?: Role;
}
