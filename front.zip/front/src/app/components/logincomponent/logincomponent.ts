import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../service/auth.service';

@Component({
  selector: 'app-logincomponent',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './logincomponent.html',
  styleUrl: './logincomponent.css'
})
export class LoginComponent {
  private fb = inject(FormBuilder);
  private auth = inject(AuthService);
  private router = inject(Router);

  errorMessage = '';
  loginForm = this.fb.nonNullable.group({
    username: ['', Validators.required],
    password: ['', Validators.required]
  });

  onSubmit(): void {
    if (this.loginForm.invalid) return;
    const { username, password } = this.loginForm.getRawValue();
    this.auth.login(username, password).subscribe(user => {
      if (!user) {
        this.errorMessage = 'Usuario o contraseña incorrectos.';
        return;
      }
      void this.router.navigate([user.role === 'ADMIN' ? '/admin' : '/usuario']);
    });
  }
}
