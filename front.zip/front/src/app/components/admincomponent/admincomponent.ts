import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../../service/user.service';
import { User } from '../../model/user.model';

@Component({
  selector: 'app-admincomponent',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './admincomponent.html',
  styleUrls: ['./admincomponent.css']
})
export class Admincomponent implements OnInit {
  private userService = inject(UserService);
  private fb = inject(FormBuilder);

  users: User[] = [];
  userForm: FormGroup;
  isEditing: boolean = false;
  currentUserId?: number;
  errorMessage: string = '';
  successMessage: string = '';

  constructor() {
    this.userForm = this.fb.group({
      username: ['', [Validators.required]],
      password: ['', [Validators.required]],
      edad: [0, [Validators.required, Validators.min(0)]],
      fechaDeNacimiento: ['', [Validators.required]],
      role: ['USER', [Validators.required]]
    });
  }

  ngOnInit(): void {
    this.loadUsers();
  }

  loadUsers(): void {
    this.userService.getAll().subscribe({
      next: (data) => { this.users = data; },
      error: () => { this.errorMessage = 'Error al cargar usuarios.'; }
    });
  }

  saveUser(): void {
    if (this.userForm.invalid) return;
    const userData: User = this.userForm.value;

    if (this.isEditing && this.currentUserId !== undefined) {
      this.userService.updateWithJson(this.currentUserId, userData).subscribe({
        next: (res) => {
          this.successMessage = res;
          this.resetForm();
          this.loadUsers();
        },
        error: (err) => { this.errorMessage = err.error || 'Error al actualizar.'; }
      });
    } else {
      this.userService.createWithJson(userData).subscribe({
        next: (res) => {
          this.successMessage = res;
          this.resetForm();
          this.loadUsers();
        },
        error: (err) => { this.errorMessage = err.error || 'Error al crear.'; }
      });
    }
  }

  selectForEdit(user: User): void {
    this.isEditing = true;
    this.currentUserId = user.id;
    this.userForm.patchValue({
      username: user.username,
      password: user.password || '',
      edad: user.edad,
      fechaDeNacimiento: user.fechaDeNacimiento,
      role: user.role || 'USER'
    });
  }

  deleteUser(id?: number): void {
    if (!id) return;
    if (confirm('¿Estás seguro de eliminar este usuario?')) {
      this.userService.deleteById(id).subscribe({
        next: () => { this.loadUsers(); },
        error: () => { this.errorMessage = 'Error al eliminar.'; }
      });
    }
  }

  resetForm(): void {
    this.isEditing = false;
    this.currentUserId = undefined;
    this.userForm.reset({ role: 'USER', edad: 0 });
  }
}
