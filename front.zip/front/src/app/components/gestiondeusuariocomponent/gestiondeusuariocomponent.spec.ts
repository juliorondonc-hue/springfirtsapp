import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Gestiondeusuariocomponent } from './gestiondeusuariocomponent';

describe('Gestiondeusuariocomponent', () => {
  let component: Gestiondeusuariocomponent;
  let fixture: ComponentFixture<Gestiondeusuariocomponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Gestiondeusuariocomponent],
    }).compileComponents();

    fixture = TestBed.createComponent(Gestiondeusuariocomponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
