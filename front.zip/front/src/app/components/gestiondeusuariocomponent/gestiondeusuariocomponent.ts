import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../../service/user.service';
import { User } from '../../model/user.model';
import { AuthService } from '../../service/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-gestiondeusuariocomponent',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './gestiondeusuariocomponent.html',
  styleUrls: ['./gestiondeusuariocomponent.css']
})
export class Gestiondeusuariocomponent implements OnInit {
  private userService = inject(UserService);
  private fb = inject(FormBuilder);
  private auth = inject(AuthService);
  private router = inject(Router);

  users: User[] = [];
  userForm: FormGroup;
  isEditing: boolean = false;
  currentUserId?: number;
  errorMessage: string = '';
  successMessage: string = '';

  constructor() {
    this.userForm = this.fb.group({
      username: ['', [Validators.required]],
      password: ['', [Validators.required]],
      edad: [0, [Validators.required, Validators.min(0)]],
      fechaDeNacimiento: ['', [Validators.required]],
      role: ['USER', [Validators.required]]
    });
  }

  ngOnInit(): void {
    this.loadUsers();
  }

  loadUsers(): void {
    this.userService.getAll().subscribe({
      next: (data) => {
        this.users = data;
        this.clearMessages();
      },
      error: () => {
        this.errorMessage = 'Error al cargar los usuarios.';
      }
    });
  }

  saveUser(): void {
    if (this.userForm.invalid) return;
    const userData: User = this.userForm.value;

    if (this.isEditing && this.currentUserId !== undefined) {
      this.userService.updateWithJson(this.currentUserId, userData).subscribe({
        next: (response) => {
          this.successMessage = response;
          this.resetForm();
          this.loadUsers();
        },
        error: (err) => { this.errorMessage = err.error || 'Error al actualizar.'; }
      });
    } else {
      this.userService.createWithJson(userData).subscribe({
        next: (response) => {
          this.successMessage = response;
          this.resetForm();
          this.loadUsers();
        },
        error: (err) => { this.errorMessage = err.error || 'Error al crear.'; }
      });
    }
  }

  selectForEdit(user: User): void {
    this.isEditing = true;
    this.currentUserId = user.id;
    this.userForm.patchValue({
      username: user.username,
      password: user.password || '',
      edad: user.edad,
      fechaDeNacimiento: user.fechaDeNacimiento,
      role: user.role || 'USER'
    });
  }

  deleteUser(id?: number): void {
    if (!id) return;
    if (confirm('¿Estás seguro de eliminar este usuario?')) {
      this.userService.deleteById(id).subscribe({
        next: (response) => {
          this.successMessage = response;
          this.loadUsers();
        },
        error: () => { this.errorMessage = 'Error al eliminar el usuario.'; }
      });
    }
  }

  resetForm(): void {
    this.isEditing = false;
    this.currentUserId = undefined;
    this.userForm.reset({ role: 'USER', edad: 0 });
  }

  clearMessages(): void {
    this.errorMessage = '';
    this.successMessage = '';
  }

  roleLabel(role?: User['role']): string {
    return role === 'ADMIN' ? 'Administrador' : 'Usuario';
  }

  logout(): void {
    this.auth.logout();
    void this.router.navigate(['/']);
  }
}
