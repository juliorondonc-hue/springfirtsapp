import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../service/auth.service';
import { UserService } from '../../service/user.service';
import { User } from '../../model/user.model';

@Component({
  selector: 'app-usuariocomponent',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './usuariocomponent.html',
  styleUrls: ['./usuariocomponent.css']
})
export class Usuariocomponent implements OnInit {
  private auth = inject(AuthService);
  private userService = inject(UserService);
  private router = inject(Router);
  user = this.auth.currentUser;
  users: User[] = [];
  totalUsers = 0;
  searchId: number | null = null;
  selectedUser?: User;
  lookupMessage = '';

  ngOnInit(): void {
    this.userService.getAll().subscribe(users => this.users = users);
    this.userService.count().subscribe(count => this.totalUsers = count);
  }

  checkExists(): void {
    const id = Number(this.searchId);
    if (!Number.isInteger(id) || id < 1) {
      this.lookupMessage = 'Ingresa un ID válido.';
      this.selectedUser = undefined;
      return;
    }
    this.userService.exists(id).subscribe(exists => {
      this.lookupMessage = exists ? `El usuario con ID ${id} sí existe.` : `No existe un usuario con ID ${id}.`;
    });
  }

  findById(): void {
    const id = Number(this.searchId);
    if (!Number.isInteger(id) || id < 1) {
      this.lookupMessage = 'Ingresa un ID válido.';
      this.selectedUser = undefined;
      return;
    }
    this.userService.getById(id).subscribe(user => {
      this.selectedUser = user;
      this.lookupMessage = user ? '' : `No existe un usuario con ID ${id}.`;
    });
  }

  logout(): void {
    this.auth.logout();
    void this.router.navigate(['/']);
  }
}
