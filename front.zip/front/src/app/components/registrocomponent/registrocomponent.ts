import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../../service/user.service';

@Component({
  selector: 'app-registrocomponent',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './registrocomponent.html',
  styleUrls: ['./registrocomponent.css']
})
export class RegistroComponent {
  private userService = inject(UserService);
  private fb = inject(FormBuilder);
  private router = inject(Router);

  registerForm: FormGroup;
  errorMessage: string = '';
  successMessage: string = '';

  constructor() {
    this.registerForm = this.fb.group({
      username: ['', [Validators.required]],
      password: ['', [Validators.required, Validators.minLength(8)]],
      edad: [20, [Validators.required]],
      fechaDeNacimiento: ['2006-06-12', [Validators.required]],
      role: ['USER', [Validators.required]]
    });
  }

  onSubmit(): void {
    if (this.registerForm.invalid) return;

    const finalUser = this.registerForm.value;

    this.userService.createWithJson(finalUser).subscribe({
      next: () => {
        this.successMessage = '¡Cuenta creada exitosamente!';
        setTimeout(() => this.router.navigate(['/']), 1500);
      },
      error: (err) => {
        this.errorMessage = err.error || 'Error al registrar la cuenta.';
      }
    });
  }
}
