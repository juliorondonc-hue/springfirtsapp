import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet], // <--- Agrégalos aquí
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class AppComponent {
}
